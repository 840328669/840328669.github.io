function fun() {
    box1 = 20;

      alert(box1="我是fun");
}
fun();