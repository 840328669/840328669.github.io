(function (){
    // 私有数据
    var msg = 'deDe'
    // 操作数据的函数
    function doSomeThing(){
        console.log('doSomeThing()' + msg.toUpperCase())
    }
    function doOtherThing(){
        console.log('doOtherThing()'+msg.toLowerCase())
    }
    
    // 把暴露的东西添加为window的属性
    window.myModule2 = {  
        //字符串: 函数名
        dS: doSomeThing,
        dO: doOtherThing
    }
})()